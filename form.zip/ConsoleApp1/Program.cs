﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static string GetLottoNumber(int count)
        {
            string result = "";
            try
            {
                WebClient client = new WebClient();
                using (Stream data = client.OpenRead("https://www.dhlottery.co.kr/common.do?method=getLottoNumber&amp;drwNo=" + count.ToString()))
                {
                    using (StreamReader reader = new StreamReader(data))
                    {
                        string s = reader.ReadToEnd();
                        result = s;
                        reader.Close();
                        data.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                //MessageBox.Show(ex.Message);
            }
            return result;
        }
        static void Main(string[] args)
        {

            //-------------------------------------------------
            string result = GetLottoNumber(900);
            dynamic varResult = JObject.Parse(result);
            //DataRow dr = dt.NewRow();
            //dr["회차"] = varResult["drwNo"];
            //dr["날짜"] = varResult["drwNoDate"];
            //dr["당첨금_1등"] = String.Format("{0:N0}", varResult["firstWinamnt"]);
            //dr["인원_1등"] = varResult["firstPrzwnerCo"];
            //dr["번호1"] = varResult["drwtNo1"];
            //dr["번호2"] = varResult["drwtNo2"];
            //dr["번호3"] = varResult["drwtNo3"];
            //dr["번호4"] = varResult["drwtNo4"];
            //dr["번호5"] = varResult["drwtNo5"];
            //dr["번호6"] = varResult["drwtNo6"];
            //dr["보너스번호"] = varResult["bnusNo"];

        }
    }
}

﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private Random r = new Random();  
        private int[] lot = new int[6];
        List<Lotto> mylottos = new List<Lotto>();
        public Form1()
        {
            InitializeComponent();
        }

        public void genLotto(int start)
        {
            {
                //https://www.dhlottery.co.kr/common.do?method=getLottoNumber&drwNo=1000
                mylottos.Clear();
                int count = start;

//
               //ist<hjkhjkhjkhkhjkhkhjkhjkhgfjhgfjghjgjkghkghkt<Lotto>();

                while (true)
                {
                    var json = new WebClient().DownloadString("https://www.dhlottery.co.kr/common.do?method=getLottoNumber&drwNo=" + count);
                    count++;
                    var jArray = JObject.Parse(json);
                    if (jArray["returnValue"].ToString() == "fail")
                        break;
                    Lotto l = new Lotto()
                    {
                        drwNo = jArray["drwNo"].ToString(),
                        drwNoDate = jArray["drwNoDate"].ToString(),
                        drwtNo1 = jArray["drwtNo1"].ToString(),
                        drwtNo2 = jArray["drwtNo2"].ToString(),
                        drwtNo3 = jArray["drwtNo3"].ToString(),
                        drwtNo4 = jArray["drwtNo4"].ToString(),
                        drwtNo5 = jArray["drwtNo5"].ToString(),
                        drwtNo6 = jArray["drwtNo6"].ToString(),
                        bnusNo = jArray["bnusNo"].ToString()
                    };
                    mylottos.Add(l);
                }
                //mylottos  lottos;
            }
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }


        private void button1_Click(object sender, EventArgs e)
        {

            genLotto(1000);


            int n;
            for (int i = 0; i < 6; i++)   
                lot[i] = -1;
            for (int i = 0; i < 6; i++)
            {
                while (true)
                {
                    n = r.Next() % 45 + 1;
                    if (!lot.Contains(n))
                    {                   
                        lot[i] = n;
                        break;
                    }
                }
            }

            Array.Sort(lot);  
            
            label1.Text = lot[0].ToString();
            label2.Text = lot[1].ToString();
            label3.Text = lot[2].ToString();
            label4.Text = lot[3].ToString();
            label5.Text = lot[4].ToString();
            label6.Text = lot[5].ToString();
        }
                
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Close();
        }
    }
}
    


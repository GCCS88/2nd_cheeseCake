﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project001
{
    
        public class Lotto
        {
            public string drwtNo1 { get; set; } //번호1
            public string drwtNo2 { get; set; }//번호2
            public string drwtNo3 { get; set; }//번호3
            public string drwtNo4 { get; set; }//번호4
            public string drwtNo5 { get; set; }//번호5
            public string drwtNo6 { get; set; }//번호6
            public string bnusNo { get; set; } //보너스번호
            public string drwNo { get; set; } //회차
            public string drwNoDate { get; set; } //로또 날짜
        }
    
}
